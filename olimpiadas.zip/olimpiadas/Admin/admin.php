<?php
session_start();

if (!isset($_SESSION['nombre'])) {
    header("Location: ../login.php"); 
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal de ventas por internet</title>
    <link rel="stylesheet" href="admin.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <nav class="menu">
        <div id="welcomeMessage"></div>
        <ul>
            <li><a href="index.php">Administrar</a></li>
        </ul>
    </nav>
    <br>
    <header id="header">
        <h1>Administrador De Los Productos</h1>
    </header>
    <main>
        <div class="contenedor">
            <div class="añadir">
                <h2>Añadir</h2>
                <form id="formularioAñadir">
                    <label>Nombre del producto</label>
                    <input type="text" id="productoAñadir" name="nombreDelProducto" required>
                    <label>Valor del producto</label>
                    <input type="number" id="valorAñadir" name="valorDelProducto" required>
                    <label>Stock</label>
                    <input type="number" id="existenciaAñadir" name="existenciaDelProducto" required>
                    <label>Url Imagen</label>
                    <input type="text" id="ImagenAñadir" name="urlImagen" required>
                    <input class="button" type="submit" value="Añadir">
                </form>
            </div>

            <div class="edicion">
                <h2>Editar Producto</h2>
                <form id="formularioEditar">
                    <label>Nombre del producto</label>
                    <select id="productoEditar" name="productoEditar">
                        <option value="">---</option>
                    </select>
                    <label>Atributo</label>
                    <select id="atributoEditar" name="atributoEditar">
                        <option value="" disabled selected>---</option>
                        <option value="nombre">Nombre</option>
                        <option value="precio">Precio</option>
                        <option value="existencia">Stock</option>
                        <option value="imagen">Imagen</option>
                    </select>
                    <label>Nuevo valor</label>
                    <input type="text" id="nuevoAtributo" name="nuevoAtributo">
                    <input class="button" type="submit" value="Editar">
                </form>
                <div id="atributoActual">
                </div>
            </div>
            <div class="eliminar">
                <h2>Eliminar</h2>
                <form id="formularioEliminar">
                    <label>Nombre del producto</label>
                    <select id="productoEliminar" name="productoEliminar">
                        <option value="">---</option>
                    </select>
                    <input class="button" type="submit" value="Eliminar">
                </form>
            </div>
        </div>
    </main>
    <script src="scripts.js"></script>
</body>
</html>
