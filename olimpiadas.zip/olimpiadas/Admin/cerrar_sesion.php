<?php
session_start();
session_destroy(); 
header("Location: inicios_usuarios/inicio_registro_usuarios.php"); 
exit();
?>
