<?php
include("conexion_db.php");

header('Content-Type: application/json');

if (!$conn) {
    echo json_encode(['error' => 'Error en la conexión a la base de datos: ' . mysqli_connect_error()]);
    exit();
}

$codigoCompra = $_GET['codigo_compra'];

$query = "
    SELECT p.nombre, p.imagen, c.cantidad, p.precio
    FROM compras c
    JOIN productos p ON c.producto_id = p.id
    WHERE c.id = $codigoCompra
";
$result = mysqli_query($conn, $query);

if (!$result) {
    echo json_encode(['error' => 'Error en la consulta: ' . mysqli_error($conn)]);
    exit();
}

$detalles = [];
while ($row = mysqli_fetch_assoc($result)) {
    $detalles[] = $row;
}

mysqli_close($conn);
echo json_encode($detalles);
?>
