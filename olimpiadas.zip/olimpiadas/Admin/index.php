<?php
session_start();

if (!isset($_SESSION['nombre'])) {
    header("Location: inicios_usuarios/inicio_registro_usuarios.php");
    exit();
}

$nombreUsuario = $_SESSION['nombre'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <title>Página Principal</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>

    <header>
        <nav class="menu">
            <div id="welcomeMessage">Bienvenido, <?php echo htmlspecialchars($nombreUsuario); ?> !!</div>
            <button onclick="location.href='cerrar_sesion.php'" class="cerrar-sesion-btn">Cerrar Sesión</button>
        </nav>
    </header>

    <main>
        <div class="container">
            <div class="cuadro" onclick="location.href='admin.php'">
                <h2>Administrar Productos</h2>
            </div>
            <div class="cuadro" onclick="location.href='mostrar_producto.php'">
                <h2>Mostrar Productos</h2>
            </div>
            <div class="cuadro" onclick="location.href='tabla_compra.php'">
                <h2>Tabla de Resumen Clientes</h2>
            </div>
        </div>
    </main>



</body>
</html>
