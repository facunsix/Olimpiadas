<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  <link rel="stylesheet" href="style.css">
  <title>Página de inicio de sesión</title>
</head>

<body>

  <div class="container" id="container">
    <div class="form-container sign-in">
    <form action="login.php" method="POST">
    <h1>Iniciar sesión</h1>
    <br>
    <br>
    <input type="type" name="nombre" placeholder="Nombre" required>
    <input type="email" name="correo" placeholder="Correo electrónico" required>
    <input type="password" name="contrasena" placeholder="Contraseña" required>
    <br>
    <br>
    <button type="submit">Ingresar</button>
    </form>

    </div>
  </div>
</body>

</html>
