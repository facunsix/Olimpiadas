<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "olimpiadas";
$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $correo = $_POST['correo'];
    $contrasena = $_POST['contrasena'];
    $sql = "SELECT * FROM iniciosecionadmin WHERE correo = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $correo);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if ($contrasena == $row['contrasena']) {
            session_start();
            $_SESSION['nombre'] = $row['nombre'];
            header("Location: ../index.php");
            exit();
        } else {
            echo "Contraseña incorrecta.";
        }
        
    } else {
        echo "No existe una cuenta con este correo electrónico.";
    }
}

$conn->close();
?>
