<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Productos</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<header class="header">
    <div class="titulo">
        <h2><a href="mostrar_producto.php" class="titulo-link">Tienda elementos deportivos</a></h2>
    </div>
    <nav class="menu">
        <ul>
            <li><a href="index.php">Administrar</a></li>
            
        </ul>
    </nav>
</header>
<body>
    <h1 class="encabezado">Elementos Deportivos</h1>
    <div class="productos-container">
        <?php
        include("conexion_db.php");

        $sql = "SELECT * FROM productos";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $descripcion_detallada = isset($row["descripcion_detallada"]) ? $row["descripcion_detallada"] : 'Descripción no disponible';
                
                echo '<div class="producto" onclick="mostrarDetalle(\'' . $row["nombre"] . '\', \'' . $row["precio"] . '\', \'' . $row["existencia"] . '\', \'' . $descripcion_detallada . '\')">';
                echo '<img src="' . $row["imagen"] . '" alt="' . $row["nombre"] . '" class="producto-imagen">';
                echo '<div class="producto-info">';
                echo '<h3>' . $row["nombre"] . '</h3>';
                echo '<p>Precio: $' . $row["precio"] . '</p>';
                echo '<p>Stock: ' . $row["existencia"] . '</p>';            
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo "No hay productos disponibles.";
        }

        mysqli_close($conn);
        ?>
    </div>
    <div id="detalle-producto" class="detalle-producto">
        <div class="detalle-contenido">
            <h2 id="detalle-titulo"></h2>
            <p id="detalle-precio"></p>
            <p id="detalle-existencia"></p>
            <div id="detalle-mas-info">
            </div>
            <button id="cerrar-detalle" class="detalle-btn" onclick="cerrarDetalle()">Cerrar</button>
        </div>
    </div>

 
</body>
</html>

