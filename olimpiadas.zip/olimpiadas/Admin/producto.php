<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "olimpiadas";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Conexión fallida: " . $conn->connect_error);
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
  case 'listar':
    $sql = "SELECT id, nombre FROM productos";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      $productos = [];
      while ($row = $result->fetch_assoc()) {
        $productos[] = $row;
      }
      echo json_encode($productos);
    } else {
      echo json_encode([]);
    }
    break;

  case 'agregar':
    $nombre = isset($_POST['nombreDelProducto']) ? $conn->real_escape_string($_POST['nombreDelProducto']) : '';
    $valor = isset($_POST['valorDelProducto']) ? floatval($_POST['valorDelProducto']) : 0;
    $existencia = isset($_POST['existenciaDelProducto']) ? intval($_POST['existenciaDelProducto']) : 0;
    $imagen = isset($_POST['urlImagen']) ? $conn->real_escape_string($_POST['urlImagen']) : '';
    
    if ($nombre && $valor && $existencia && $imagen) {
      $sql = "INSERT INTO productos (nombre, precio, existencia, imagen) VALUES ('$nombre', $valor, $existencia, '$imagen')";
      if ($conn->query($sql) === TRUE) {
        echo 'Producto agregado con éxito';
      } else {
        echo 'Error: ' . $conn->error;
      }
    } else {
      echo 'Todos los campos son requeridos';
    }
    break;

  case 'editar':
    $id = isset($_POST['productoEditar']) ? intval($_POST['productoEditar']) : 0;
    $atributo = isset($_POST['atributoEditar']) ? $conn->real_escape_string($_POST['atributoEditar']) : '';
    $nuevoValor = isset($_POST['nuevoAtributo']) ? $conn->real_escape_string($_POST['nuevoAtributo']) : '';

    if ($id && $atributo && $nuevoValor) {
      $atributosValidos = ['nombre', 'precio', 'existencia', 'imagen'];
      if (in_array($atributo, $atributosValidos)) {
        $sql = "UPDATE productos SET $atributo = '$nuevoValor' WHERE id = $id";
        if ($conn->query($sql) === TRUE) {
          echo 'Producto editado con éxito';
        } else {
          echo 'Error: ' . $conn->error;
        }
      } else {
        echo 'Atributo no válido';
      }
    } else {
      echo 'ID, atributo y nuevo valor son requeridos';
    }
    break;

  case 'eliminar':
    $id = isset($_POST['productoEliminar']) ? intval($_POST['productoEliminar']) : 0;
    if ($id) {
      $sql = "DELETE FROM productos WHERE id = $id";
      if ($conn->query($sql) === TRUE) {
        echo 'Producto eliminado con éxito';
      } else {
        echo 'Error: ' . $conn->error;
      }
    } else {
      echo 'ID de producto requerido';
    }
    break;

  default:
    echo 'Acción no reconocida';
    break;
}

$conn->close();
?>
