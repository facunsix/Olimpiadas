document.addEventListener('DOMContentLoaded', function() {
  function cargarProductos() {
    fetch('producto.php?action=listar')
      .then(response => response.json())
      .then(data => {
        let selectEditar = document.getElementById('productoEditar');
        let selectEliminar = document.getElementById('productoEliminar');
        selectEditar.innerHTML = '<option value="">---</option>';
        selectEliminar.innerHTML = '<option value="">---</option>';

        data.forEach(producto => {
          let optionEditar = document.createElement('option');
          optionEditar.value = producto.id;
          optionEditar.textContent = producto.nombre;
          selectEditar.appendChild(optionEditar);

          let optionEliminar = document.createElement('option');
          optionEliminar.value = producto.id;
          optionEliminar.textContent = producto.nombre;
          selectEliminar.appendChild(optionEliminar);
        });
      })
      .catch(error => {
        console.error('Error al cargar productos:', error);
      });
  }

  cargarProductos(); 

  document.getElementById('formularioAñadir').addEventListener('submit', function(event) {
    event.preventDefault();
    let form = this;
    let formData = new FormData(form);

    fetch('producto.php?action=agregar', {
      method: 'POST',
      body: formData
    })
    .then(response => response.text())
    .then(result => {
      alert(result);
      form.reset(); 
      cargarProductos();
    })
    .catch(error => {
      console.error('Error al añadir producto:', error);
    });
  });
  document.getElementById('formularioEditar').addEventListener('submit', function(event) {
    event.preventDefault();
    let form = this;
    let formData = new FormData(form);

    fetch('producto.php?action=editar', {
      method: 'POST',
      body: formData
    })
    .then(response => response.text())
    .then(result => {
      alert(result);
      form.reset(); 
      cargarProductos(); 
    })
    .catch(error => {
      console.error('Error al editar producto:', error);
    });
  });
  document.getElementById('formularioEliminar').addEventListener('submit', function(event) {
    event.preventDefault();
    let form = this;
    let formData = new FormData(form);

    fetch('producto.php?action=eliminar', {
      method: 'POST',
      body: formData
    })
    .then(response => response.text())
    .then(result => {
      alert(result);
      form.reset(); 
      cargarProductos(); 
    })
    .catch(error => {
      console.error('Error al eliminar producto:', error);
    });
  });
});
