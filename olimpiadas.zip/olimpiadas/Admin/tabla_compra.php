<?php
session_start();
include("conexion_db.php");

if (!$conn) {
    die("Error en la conexión a la base de datos: " . mysqli_connect_error());
}
$query = "
    SELECT c.id AS codigo_compra, c.usuario_id, c.fecha, p.precio, c.cantidad, u.nombre AS usuario_nombre
    FROM compras c
    JOIN productos p ON c.producto_id = p.id
    JOIN iniciosecionclientes u ON c.usuario_id = u.id
    ORDER BY c.usuario_id, c.fecha DESC
";
$result = mysqli_query($conn, $query);

if (!$result) {
    die("Error en la consulta: " . mysqli_error($conn));
}

$compras = [];
while ($row = mysqli_fetch_assoc($result)) {
    $compras[] = $row;
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compras de los Clientes</title>
    <link rel="stylesheet" href="tablaresumen.css">
</head>
<body>
<nav class="menu">
    <div id="welcomeMessage"></div>
    <ul>
        <li><a href="index.php">Administrar</a></li>
    </ul>
</nav>
<h1>Tabla De Compras de los Clientes</h1>

<table>
    <thead>
        <tr>
            <th>Usuario</th>
            <th>Código de Compra</th>
            <th>Fecha de Compra</th>
            <th>Cantidad</th>
            <th>Monto</th>
            <th>Código de Pago</th>
            <th>Estado</th>
            <th>Detalles</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $currentUserId = null;
        $totalMonto = 0;

        foreach ($compras as $compra) {
            if ($currentUserId !== $compra['usuario_id']) {
                if ($currentUserId !== null) {
                    echo "<tr class='group-separator'><td colspan='8'>Total para el usuario $currentUserId: $" . number_format($totalMonto, 2) . "</td></tr>";
                }
                $currentUserId = $compra['usuario_id'];
                $totalMonto = 0;
                echo "<tr class='group-separator'>";
            }

            $monto = $compra['precio'] * $compra['cantidad'];
            $totalMonto += $monto;

            echo "<tr>";
            echo "<td>{$compra['usuario_nombre']}</td>";
            echo "<td>{$compra['codigo_compra']}</td>";
            echo "<td>{$compra['fecha']}</td>";
            echo "<td>{$compra['cantidad']}</td>";
            echo "<td>$" . number_format($monto, 2) . "</td>";
            echo "<td>--</td>"; 
            echo "<td>Enviando</td>"; 
            echo "<td><button class='ver-detalle' data-codigo-compra='{$compra['codigo_compra']}'>Ver Detalle</button></td>";
            echo "</tr>";
        }
        if ($currentUserId !== null) {
            echo "<tr class='group-separator'><td colspan='8'>Total para el usuario $currentUserId: $" . number_format($totalMonto, 2) . "</td></tr>";
        }
        ?>
    </tbody>
</table>

<div id="detalle-modal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Detalles de Compra</h2>
        <div id="detalle-contenido"></div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const modal = document.getElementById('detalle-modal');
        const closeBtn = document.querySelector('.modal .close');
        const detalleContenido = document.getElementById('detalle-contenido');

        document.querySelectorAll('.ver-detalle').forEach(button => {
            button.addEventListener('click', (event) => {
                const codigoCompra = event.target.dataset.codigoCompra;
                fetch('detalles_compra.php?codigo_compra=' + codigoCompra)
                    .then(response => response.json())
                    .then(data => {
                        let html = `<h3>Detalles de Compra: ${codigoCompra}</h3>`;
                        html += '<table>';
                        html += '<thead><tr><th>Artículo</th><th>Imagen</th><th>Cantidad</th><th>Precio Unitario</th><th>Total</th></tr></thead><tbody>';

                        let totalMonto = 0;
                        data.forEach(detalle => {
                            const precioUnitario = parseFloat(detalle.precio.replace(/[^0-9.-]+/g, ""));
                            const subtotal = precioUnitario * detalle.cantidad;
                            totalMonto += subtotal;

                            html += `<tr>
                                <td>${detalle.nombre}</td>
                                <td><img src="${detalle.imagen}" alt="${detalle.nombre}" width="100"></td>
                                <td>${detalle.cantidad}</td>
                                <td>$${precioUnitario.toFixed(2)}</td>
                                <td>$${subtotal.toFixed(2)}</td>
                            </tr>`;
                        });

                        html += `<tr><td colspan="4"><b>Total</b></td><td>$${totalMonto.toFixed(2)}</td></tr></tbody></table>`;
                        detalleContenido.innerHTML = html;
                        modal.style.display = 'flex';
                    })
                    .catch(error => console.error('Error:', error));
            });
        });

        closeBtn.addEventListener('click', () => {
            modal.style.display = 'none';
        });

        window.addEventListener('click', (event) => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    });
</script>
</body>
</html>
