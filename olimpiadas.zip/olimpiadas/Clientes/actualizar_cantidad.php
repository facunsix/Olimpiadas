<?php
session_start();
include("conexion_db.php");
if (!$conn) {
    echo json_encode(['error' => 'Error en la conexión a la base de datos: ' . mysqli_connect_error()]);
    exit();
}

if (!isset($_SESSION['usuario'])) {
    echo json_encode(['error' => 'No estás logueado']);
    exit();
}

$usuario = $_SESSION['usuario'];
$productoId = isset($_POST['producto_id']) ? intval($_POST['producto_id']) : 0;
$cantidad = isset($_POST['cantidad']) ? intval($_POST['cantidad']) : 0;

if ($productoId > 0 && $cantidad > 0) {
    $updateQuery = "UPDATE carritos SET cantidad = $cantidad WHERE usuario = '$usuario' AND producto_id = $productoId";
    if (mysqli_query($conn, $updateQuery)) {
        $subtotalQuery = "SELECT carritos.producto_id, productos.precio, SUM(carritos.cantidad * productos.precio) AS subtotal
                          FROM carritos
                          INNER JOIN productos ON carritos.producto_id = productos.id
                          WHERE carritos.usuario = '$usuario'
                          GROUP BY carritos.producto_id";
        $subtotalResult = mysqli_query($conn, $subtotalQuery);
        
        $subtotal = 0;
        $productos = [];

        while ($row = mysqli_fetch_assoc($subtotalResult)) {
            $productos[$row['producto_id']] = [
                'precio' => number_format($row['precio'], 2, '.', ''),
                'subtotal' => number_format($row['subtotal'], 2, '.', '')
            ];
            $subtotal += $row['subtotal'];
        }
        echo json_encode([
            'subtotal' => number_format($subtotal, 2, '.', ''),
            'productos' => $productos
        ]);
    } else {
        echo json_encode(['error' => 'Error al actualizar la cantidad']);
    }
} else {
    echo json_encode(['error' => 'Datos no válidos']);
}

mysqli_close($conn);
?>
