<?php
session_start();
include("conexion_db.php");

if (!$conn) {
    echo json_encode(['error' => 'Error en la conexión a la base de datos: ' . mysqli_connect_error()]);
    exit();
}

if (!isset($_SESSION['usuario'])) {
    echo json_encode(['error' => 'No estás logueado']);
    exit();
}

$usuario = $_SESSION['usuario'];
$productoId = isset($_POST['producto_id']) ? intval($_POST['producto_id']) : 0;

if ($productoId > 0) {
    error_log("Usuario: $usuario, Producto ID: $productoId");
    $query = "SELECT * FROM carritos WHERE usuario = '$usuario' AND producto_id = $productoId";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $updateQuery = "UPDATE carritos SET cantidad = cantidad + 1 WHERE usuario = '$usuario' AND producto_id = $productoId";
        mysqli_query($conn, $updateQuery);
    } else {
        $insertQuery = "INSERT INTO carritos (usuario, producto_id, cantidad) VALUES ('$usuario', $productoId, 1)";
        mysqli_query($conn, $insertQuery);
    }
    $totalQuery = "SELECT SUM(cantidad) AS cantidad_total FROM carritos WHERE usuario = '$usuario'";
    $totalResult = mysqli_query($conn, $totalQuery);
    $totalRow = mysqli_fetch_assoc($totalResult);
    echo json_encode(['cantidad_carrito' => $totalRow['cantidad_total']]);
} else {
    echo json_encode(['error' => 'Producto no válido']);
}

mysqli_close($conn);
?>
