<?php
session_start();
include("conexion_db.php");

if (!isset($_SESSION['usuario'])) {
    header('Location: index.php'); 
    exit();
}

$usuario = $_SESSION['usuario'];
$query = "SELECT carritos.cantidad, productos.id, productos.nombre, productos.precio, productos.imagen 
          FROM carritos 
          INNER JOIN productos ON carritos.producto_id = productos.id 
          WHERE carritos.usuario = '$usuario'";
$result = mysqli_query($conn, $query);

$productos = [];
$subtotal = 0;

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $productos[] = $row;
        $subtotal += $row['precio'] * $row['cantidad'];
    }
} else {
    echo "El carrito está vacío.";
    exit;
}
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito de Compras</title>
    <link rel="stylesheet" href="estilos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="carrito_script.js" defer></script>
    <script src="pago.js"></script>

</head>
<body>
    <header class="header">
        <div class="header-left">
            <div class="titulo">
                <h2><a href="index.php" class="titulo-link">Tienda elementos deportivos</a></h2>
            </div>
        </div>
        <div class="header-right">
        <?php
            if (isset($_SESSION['usuario'])) {
                $usuarioNombre = $_SESSION['usuario'];
                echo '<div class="usuario-info">';
                echo '<i class="fas fa-user"></i> ' . htmlspecialchars($usuarioNombre);
                echo '</div>';
            }
            ?>
       
            <button onclick="location.href='cerrar_sesion.php'" class="cerrar-sesion-btn">Cerrar Sesión</button>
        </div>
    </header>

    <div class="carrito-container">
        <table class="carrito-table">
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Artículo</th>
                    <th>Descripción</th>
                    <th>Precio</th>
                    <th>Cantidad</th>
                    <th>Total</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $item = 1; ?>
                <?php foreach ($productos as $producto): ?>
                <tr>
                    <td><?php echo $item++; ?></td>
                    <td><img src="<?php echo $producto['imagen']; ?>" class="producto-imagen-mini"></td>
                    <td><?php echo $producto['nombre']; ?></td>
                    <td>$<?php echo number_format($producto['precio'], 2); ?></td>
                    <td><input type="number" class="cantidad-input" data-id="<?php echo $producto['id']; ?>" value="<?php echo $producto['cantidad']; ?>" min="1"></td>
                    <td class="total" data-id="<?php echo $producto['id']; ?>">$<?php echo number_format($producto['precio'] * $producto['cantidad'], 2); ?></td>
                    <td><i class="fa fa-trash eliminar-producto" data-id="<?php echo $producto['id']; ?>"></i></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="resumen-compra">
            <h2>Generar Compra</h2>
            <p>Subtotal: $<span id="subtotal"><?php echo number_format($subtotal, 2); ?></span></p>
            <p>Precio Envío: $<span id="precio-envio">0</span></p>
            <p>Descuento: $<span id="descuento">0</span></p>
            <p>Total a Pagar: $<span id="total-pagar"><?php echo number_format($subtotal, 2); ?></span></p>
            <button id="generar-compra-btn" disabled>Generar Compra</button>
            <button id="realizar-pago-btn">Realizar Pago</button>
        </div>
<div id="pago-modal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Realizar Pago</h2>
        <p>Ingrese los números de tarjeta (modo de prueba):</p>
        <div class="input-container">
            <i id="numero-tarjeta-icon" class="fas fa-credit-card"></i>
            <input type="text" id="numero-tarjeta" placeholder="Número de tarjeta">
        </div>
        <button id="pagar-btn">Pagar</button>
        <p id="pago-status"></p>
    </div>
</div>



    </div>
</body>
</html>
