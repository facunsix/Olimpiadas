$(document).ready(function() {
    $(".agregar-carrito").click(function() {
        var productoId = $(this).data("id");

        $.ajax({
            url: "agregar_carrito.php",
            method: "POST",
            data: {
                producto_id: productoId
            },
            success: function(response) {
                try {
                    var jsonResponse = JSON.parse(response);
                    console.log(jsonResponse);

                    if (jsonResponse.error) {
                        console.error("Error:", jsonResponse.error);
                    } else {
                        $("#cantidad-carrito").text(jsonResponse.cantidad_carrito);
                        actualizarSubtotal();
                    }
                } catch (e) {
                    console.error("Error al analizar la respuesta JSON:", e);
                    console.error("Respuesta recibida:", response);
                }
            },
            error: function(xhr, status, error) {
                console.error("Error en la solicitud AJAX:", status, error);
            }
        });
    });
    $(".eliminar-producto").click(function() {
        var productoId = $(this).data("id");
        var row = $(this).closest("tr");

        $.ajax({
            url: "eliminar_producto.php",
            method: "POST",
            data: {
                producto_id: productoId
            },
            success: function(response) {
                try {
                    var jsonResponse = JSON.parse(response);
                    console.log(jsonResponse);

                    if (jsonResponse.error) {
                        console.error("Error:", jsonResponse.error);
                    } else {
                        $("#cantidad-carrito").text(jsonResponse.cantidad_carrito);
                        row.remove();
                        actualizarSubtotal();
                    }
                } catch (e) {
                    console.error("Error al analizar la respuesta JSON:", e);
                    console.error("Respuesta recibida:", response);
                }
            },
            error: function(xhr, status, error) {
                console.error("Error en la solicitud AJAX:", status, error);
            }
        });
    });
    $(".cantidad-input").on('change', function() {
        var productoId = $(this).data("id");
        var cantidad = $(this).val();

        if (isNaN(cantidad) || cantidad <= 0) {
            console.error("Cantidad no válida:", cantidad);
            return;
        }

        $.ajax({
            url: "actualizar_cantidad.php",
            method: "POST",
            data: {
                producto_id: productoId,
                cantidad: cantidad
            },
            success: function(response) {
                try {
                    var jsonResponse = JSON.parse(response);
                    console.log("Respuesta del servidor:", jsonResponse);

                    if (jsonResponse.error) {
                        console.error("Error:", jsonResponse.error);
                    } else {
                        var precio = parseFloat(jsonResponse.productos[productoId].precio);
                        var subtotalProducto = parseFloat(jsonResponse.productos[productoId].subtotal);

                        if (isNaN(precio)) {
                            console.error("Precio no válido para el producto ID:", productoId);
                            return;
                        }
                        $(".total[data-id='" + productoId + "']").text("$" + subtotalProducto.toFixed(2));
                        var subtotal = parseFloat(jsonResponse.subtotal);

                        $("#subtotal").text(subtotal.toFixed(2));
                        var precioEnvio = parseFloat($("#precio-envio").text()) || 0;
                        var descuento = parseFloat($("#descuento").text()) || 0;
                        var totalPagar = subtotal + precioEnvio - descuento;
                        $("#total-pagar").text(totalPagar.toFixed(2));
                    }
                } catch (e) {
                    console.error("Error al analizar la respuesta JSON:", e);
                    console.error("Respuesta recibida:", response);
                }
            },
            error: function(xhr, status, error) {
                console.error("Error en la solicitud AJAX:", status, error);
            }
        });
    });
    $(".comprar-ahora").click(function() {
        var productoId = $(this).data("id");

        $.ajax({
            url: "agregar_carrito.php",
            method: "POST",
            data: {
                producto_id: productoId
            },
            success: function(response) {
                try {
                    var jsonResponse = JSON.parse(response);
                    console.log(jsonResponse);

                    if (jsonResponse.error) {
                        console.error("Error:", jsonResponse.error);
                    } else {
                        window.location.href = "carrito.php";
                    }
                } catch (e) {
                    console.error("Error al analizar la respuesta JSON:", e);
                    console.error("Respuesta recibida:", response);
                }
            },
            error: function(xhr, status, error) {
                console.error("Error en la solicitud AJAX:", status, error);
            }
        });
    });

    function actualizarSubtotal() {
        var subtotal = 0;

        $(".total").each(function() {
            var text = $(this).text().replace('$', '');
            var value = parseFloat(text);

            if (!isNaN(value)) {
                subtotal += value;
            } else {
                console.warn("No se pudo convertir el texto a número:", text);
            }
        });

        $("#subtotal").text(subtotal.toFixed(2));
        var precioEnvio = parseFloat($("#precio-envio").text()) || 0;
        var descuento = parseFloat($("#descuento").text()) || 0;
        var totalPagar = subtotal + precioEnvio - descuento;
        $("#total-pagar").text(totalPagar.toFixed(2));
    }
});
