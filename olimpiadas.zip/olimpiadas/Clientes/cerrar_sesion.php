<?php
session_start();
session_unset();
session_destroy();
header("Location: inicios_usuarios/inicio_registro_usuarios.php"); 
exit();
?>
