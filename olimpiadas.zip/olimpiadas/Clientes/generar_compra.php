<?php
session_start();
include("conexion_db.php");

header('Content-Type: application/json');

if (!$conn) {
    echo json_encode(['error' => 'Error en la conexión a la base de datos: ' . mysqli_connect_error()]);
    exit();
}

if (!isset($_SESSION['usuario'])) {
    echo json_encode(['error' => 'No estás logueado']);
    exit();
}

$usuario = mysqli_real_escape_string($conn, $_SESSION['usuario']);
$usuarioQuery = "SELECT id FROM iniciosecionclientes WHERE nombre = '$usuario'";
$usuarioResult = mysqli_query($conn, $usuarioQuery);

if (!$usuarioResult) {
    echo json_encode(['error' => 'Error en la consulta del usuario: ' . mysqli_error($conn)]);
    exit();
}

$usuarioData = mysqli_fetch_assoc($usuarioResult);

if (!$usuarioData) {
    echo json_encode(['error' => 'Usuario no encontrado']);
    exit();
}

$usuarioId = $usuarioData['id'];
$query = "SELECT producto_id, cantidad FROM carritos WHERE usuario = '$usuario'";
$result = mysqli_query($conn, $query);

if (!$result) {
    echo json_encode(['error' => 'Error en la consulta del carrito: ' . mysqli_error($conn)]);
    exit();
}

if (mysqli_num_rows($result) > 0) {
    $totalMonto = 0;
    $productos = [];
    mysqli_begin_transaction($conn);

    try {
        while ($row = mysqli_fetch_assoc($result)) {
            $productoQuery = "SELECT precio, existencia FROM productos WHERE id = " . $row['producto_id'];
            $productoResult = mysqli_query($conn, $productoQuery);

            if (!$productoResult) {
                throw new Exception('Error en la consulta del producto: ' . mysqli_error($conn));
            }

            $producto = mysqli_fetch_assoc($productoResult);
            if (!$producto) {
                throw new Exception('Producto no encontrado');
            }

            $precio = $producto['precio'];
            $existencia = $producto['existencia'];
            if ($row['cantidad'] > $existencia) {
                throw new Exception('No hay suficiente stock para el producto ID ' . $row['producto_id']);
            }
            $totalMonto += $precio * $row['cantidad'];
            $productos[] = [
                'producto_id' => $row['producto_id'],
                'cantidad' => $row['cantidad']
            ];
        }
        foreach ($productos as $producto) {
            $insertQuery = "INSERT INTO compras (usuario_id, monto, producto_id, cantidad) VALUES ('$usuarioId', '$totalMonto', " . $producto['producto_id'] . ", " . $producto['cantidad'] . ")";
            if (!mysqli_query($conn, $insertQuery)) {
                throw new Exception('Error al insertar en la tabla de compras: ' . mysqli_error($conn));
            }
            $updateStockQuery = "UPDATE productos SET existencia = existencia - " . $producto['cantidad'] . " WHERE id = " . $producto['producto_id'];
            if (!mysqli_query($conn, $updateStockQuery)) {
                throw new Exception('Error al actualizar el stock del producto ID ' . $producto['producto_id'] . ': ' . mysqli_error($conn));
            }
        }
        $deleteQuery = "DELETE FROM carritos WHERE usuario = '$usuario'";
        if (!mysqli_query($conn, $deleteQuery)) {
            throw new Exception('Error al limpiar el carrito: ' . mysqli_error($conn));
        }
        mysqli_commit($conn);
        echo json_encode(['success' => 'Compra generada exitosamente']);
    } catch (Exception $e) {
        mysqli_rollback($conn);
        echo json_encode(['error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['error' => 'El carrito está vacío']);
}

mysqli_close($conn);
?>
