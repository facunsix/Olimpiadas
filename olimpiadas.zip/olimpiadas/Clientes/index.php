<?php
session_start();
include("conexion_db.php");

$carritoCantidad = 0;

if (isset($_SESSION['usuario'])) {
    $usuario = $_SESSION['usuario'];
    $carritoQuery = "SELECT SUM(cantidad) AS cantidad_total FROM carritos WHERE usuario = '$usuario'";
    $carritoResult = mysqli_query($conn, $carritoQuery);

    if ($carritoRow = mysqli_fetch_assoc($carritoResult)) {
        $carritoCantidad = $carritoRow['cantidad_total'] ?? 0; 
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Productos</title>
    <link rel="stylesheet" href="estilos.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="carrito_script.js"></script>
</head>
<body>
    <header class="header">
        <div class="header-left">
            <div class="titulo">
                <h2><a href="index.php" class="titulo-link">Tienda elementos deportivos</a></h2>
            </div>
            <div class="carrito-item">
                <a href="carrito.php" class="carrito-link"><i class="fa fa-shopping-cart"></i> (<span id="cantidad-carrito"><?php echo $carritoCantidad; ?></span>) Carrito</a>
            </div>
        </div>
        <nav class="menu">
            <form class="buscador-form" method="GET" action="index.php">
                <input type="text" name="nombre" id="buscador" placeholder="Buscar por nombre" required>
                <button type="submit"><i class="fas fa-search"></i></button>
            </form>
        </nav>
        <div class="header-right">
            <?php
            if (isset($_SESSION['usuario'])) {
                $usuarioNombre = $_SESSION['usuario'];
                echo '<div class="usuario-info">';
                echo '<i class="fas fa-user"></i> ' . htmlspecialchars($usuarioNombre);
                echo '</div>';
            }
            ?>

            <button onclick="location.href='cerrar_sesion.php'" class="cerrar-sesion-btn">Cerrar Sesión</button>
        </div>
    </header>
    
    <h1 class="encabezado">Elementos Deportivos</h1>
    <div class="productos-container">
    <?php
    $nombreBuscado = isset($_GET['nombre']) ? $_GET['nombre'] : '';
    $sql = "SELECT * FROM productos WHERE nombre LIKE '%$nombreBuscado%'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo '<div class="producto" id="' . $row["id"] . '">';
            echo '<img src="' . $row["imagen"] . '" alt="' . $row["nombre"] . '" class="producto-imagen">';
            echo '<div class="producto-info">';
            echo '<h3>' . $row["nombre"] . '</h3>';
            echo '<p>Precio: $' . $row["precio"] . '</p>';
            echo '<p>Stock: ' . $row["existencia"] . '</p>';
            echo '<div class="botones-producto">';
            echo '<button class="agregar-carrito" data-id="' . $row["id"] . '">Añadir al Carrito</button>';
            echo '<button class="comprar-ahora" data-id="' . $row["id"] . '">Comprar</button>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }
    } else {
        echo "<p>No hay productos disponibles o no se encontraron resultados.</p>";
    }
    mysqli_close($conn);
    ?>
    </div>
</body>
</html>
