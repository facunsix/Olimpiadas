<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  <link rel="stylesheet" href="style.css">
  <title>Inicio de sesión</title>
</head>
<body>

  <div class="container" id="container">
    <div class="form-container sign-up">
      <form id="signupForm" method="POST" action="login.php">
        <h1>Crear cuenta</h1>
        <input type="text" id="signupNombre" name="nombre" placeholder="Nombre" required>
        <input type="email" id="signupCorreo" name="correo" placeholder="Correo electrónico" required>
        <input type="password" id="signupContraseña" name="contraseña" placeholder="Contraseña" required>
        <input type="hidden" name="action" value="register"> 
        <button type="submit">Registrarse</button>
        <p id="signupMessage" style="color: red;"></p>
      </form>
    </div>
    <div class="form-container sign-in">
      <form id="signinForm" method="POST" action="login.php">
        <h1>Iniciar sesión</h1>
        <input type="email" id="signinCorreo" name="correo" placeholder="Correo electrónico" required>
        <input type="password" id="signinContraseña" name="contraseña" placeholder="Contraseña" required>
        <input type="hidden" name="action" value="login"> 
        <button type="submit">Iniciar sesión</button>
        <p id="signinMessage" style="color: red;"></p>
      </form>
    </div>
    
    <div class="toggle-container">
      <div class="toggle">
        <div class="toggle-panel toggle-left">
          <h1>¡Bienvenido de nuevo!</h1>
          <p>Ingrese sus datos personales para ingresar a nuestro sitio web</p>
          <button class="hidden" id="login">Iniciar sesión</button>
        </div>
        <div class="toggle-panel toggle-right">
          <h1>¡Hola! ¿Cómo estás?</h1>
          <p>Regístrate con tus datos personales para ingresar a nuestro sitio web</p>
          <button class="hidden" id="register">Registrarse</button>
        </div>
      </div>
    </div>
  </div>

  <script src="app.js"></script>
</body>
</html>
