<?php
session_start(); 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "olimpiadas";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['action'])) {
        $action = $_POST['action']; 

        if ($action == 'register') {
            $nombre = $_POST['nombre'];
            $correo = $_POST['correo'];
            $contraseña = password_hash($_POST['contraseña'], PASSWORD_DEFAULT);
            $sql = "SELECT * FROM iniciosecionclientes WHERE correo='$correo'";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "El correo ya está registrado.";
            } else {
                $sql = "INSERT INTO iniciosecionclientes (nombre, correo, contraseña) VALUES ('$nombre', '$correo', '$contraseña')";
                if ($conn->query($sql) === TRUE) {
                    header("Location: inicio_registro_usuarios.php"); 
                    exit(); 
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            }
        } elseif ($action == 'login') {
            $correo = $_POST['correo'];
            $contraseña = $_POST['contraseña'];
            $sql = "SELECT * FROM iniciosecionclientes WHERE correo='$correo'";
            $result = $conn->query($sql);
        
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                if (password_verify($contraseña, $row['contraseña'])) { 
                    $_SESSION['usuario'] = $row['nombre']; 
                    $_SESSION['carrito'] = [];
        
                    header("Location: ../index.php"); 
                    exit(); 
                } else {
                    echo "Contraseña incorrecta.";
                }
            } else {
                echo "Correo no registrado.";
            }
        }
    }
}

$conn->close();
?>
