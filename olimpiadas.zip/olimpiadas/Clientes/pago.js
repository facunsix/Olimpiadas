document.addEventListener('DOMContentLoaded', () => {
    const pagoModal = document.getElementById('pago-modal');
    const realizarPagoBtn = document.getElementById('realizar-pago-btn');
    const closeBtn = document.querySelector('.modal .close');
    const pagarBtn = document.getElementById('pagar-btn');
    const generarCompraBtn = document.getElementById('generar-compra-btn');
    realizarPagoBtn.addEventListener('click', () => {
        pagoModal.style.display = 'flex';
    });
    closeBtn.addEventListener('click', () => {
        pagoModal.style.display = 'none';
    });
    window.addEventListener('click', (event) => {
        if (event.target === pagoModal) {
            pagoModal.style.display = 'none';
        }
    });
    pagarBtn.addEventListener('click', () => {
        const numeroTarjeta = document.getElementById('numero-tarjeta').value;
        if (numeroTarjeta) {
            $.ajax({
                type: 'POST',
                url: 'generar_compra.php',
                dataType: 'json',
                success: function(response) {
                    if (response.success) {
                        alert('Pago realizado exitosamente.');
                        generarCompraBtn.disabled = false;
                    } else {
                        alert('Pago realizado exitosamente.');
                        generarCompraBtn.disabled = false; 
                    }
                }
            });
        } else {
            alert('Pago realizado exitosamente.');
            generarCompraBtn.disabled = false; 
        }
    });
    generarCompraBtn.addEventListener('click', () => {
        $.ajax({
            type: 'POST',
            url: 'generar_compra.php',
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    alert('Paquete enviado.');
                } else {
                    alert('Error al generar la compra: ' + response.error);
                }
            }
        });
    });
});
