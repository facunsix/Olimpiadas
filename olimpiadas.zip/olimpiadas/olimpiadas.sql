-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-08-2024 a las 04:26:01
-- Versión del servidor: 10.4.25-MariaDB
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `olimpiadas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carritos`
--

CREATE TABLE `carritos` (
  `id` int(11) NOT NULL,
  `usuario` varchar(255) NOT NULL,
  `producto_id` int(11) NOT NULL,
  `cantidad` int(11) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `carritos`
--

INSERT INTO `carritos` (`id`, `usuario`, `producto_id`, `cantidad`) VALUES
(4, 'eva', 21, 6),
(5, 'eva', 18, 5),
(6, 'eva', 22, 7),
(7, 'eva', 28, 4),
(8, 'eva', 29, 6),
(14, 'robertito', 22, 1),
(15, 'robertito', 31, 1),
(16, 'robertito', 35, 1),
(17, 'robertito', 21, 4),
(44, 'Probando', 21, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras`
--

CREATE TABLE `compras` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  `producto_id` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `compras`
--

INSERT INTO `compras` (`id`, `usuario_id`, `monto`, `fecha`, `producto_id`, `cantidad`) VALUES
(74, 1, '127800.00', '2024-08-22 20:44:46', 30, 2),
(75, 1, '127800.00', '2024-08-22 20:44:46', 23, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `iniciosecionadmin`
--

CREATE TABLE `iniciosecionadmin` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `contrasena` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `iniciosecionadmin`
--

INSERT INTO `iniciosecionadmin` (`id`, `nombre`, `correo`, `contrasena`) VALUES
(2, 'Facundo', 'facundo@example.com', 'hola123');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `iniciosecionclientes`
--

CREATE TABLE `iniciosecionclientes` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `correo` varchar(255) NOT NULL,
  `contraseña` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `iniciosecionclientes`
--

INSERT INTO `iniciosecionclientes` (`id`, `nombre`, `correo`, `contraseña`) VALUES
(1, 'sol', 'sol@example.com', '$2y$10$bjPSkFYO1M4vBmJxc3Jxd.ZWjEGGX85nB3BS4l2UvP2EarZoE37J6'),
(2, 'Darien', 'darien@example.com', '$2y$10$qntE4uSt3Uf5BzNhtz2arOE8fMIUH0zuzAZCAI4oQOzXZ3AsVnEkG'),
(3, 'eva', 'eva@example.com', '$2y$10$IOt8LXT1zVCZBXywz37t7eXR5qUByiI/RgdCuGtoWJ0JGz5pJR6CW'),
(13, 'Facundo', 'facundo@example.com', '$2y$10$Qyu.t9prLLthneQD9/RmYeWsGScrkdTqbBgsB2w/HAsbRYHXpwJHC');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `existencia` int(11) DEFAULT NULL,
  `imagen` varchar(255) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `nombre`, `precio`, `existencia`, `imagen`, `admin_id`) VALUES
(18, 'Pelota Basquet Molten N°7 B7g2000 Fiba Indoor Outdoor', '42900.00', 21, 'https://http2.mlstatic.com/D_NQ_NP_892672-MLU72761380248_112023-O.webp', 2),
(21, 'Palo Tk Mulberry Midi Hockey Cesped Infantil Fibra De Vidrio Color Rosa - 24 Talle 24', '59800.00', 12, 'https://http2.mlstatic.com/D_NQ_NP_934056-MLU75418172988_042024-O.webp', NULL),
(22, 'Bocha Simbra Dimple En Naranja Unisex', '8172.00', 4, 'https://http2.mlstatic.com/D_NQ_NP_750417-MLU72830281313_112023-O.webp', NULL),
(23, 'Bocha Drial Hockey Profesional X 10 Combo Pack Mayorista', '38000.00', 9, 'https://http2.mlstatic.com/D_NQ_NP_996394-MLA45865515436_052021-O.webp', NULL),
(24, 'Pelota Futbol Nassau Pro Championship Profesional Cosida N°5 Campo Color Blanco/Negro', '83000.00', 7, 'https://http2.mlstatic.com/D_NQ_NP_755341-MLU75303576253_032024-O.webp', NULL),
(26, 'Medias Antideslizante Algodón Entrenamiento 3/4 Deportes X3', '12800.00', 29, 'https://http2.mlstatic.com/D_NQ_NP_971229-MLA75164139138_032024-O.webp', NULL),
(28, 'Antiparras Lente Natación + Gorro Lycra Estuche Tapones Oído', '9500.00', 24, 'https://http2.mlstatic.com/D_NQ_NP_774271-MLA76183009132_052024-O.webp', NULL),
(29, 'Gilbert Pelota Rugby G-tr 3000 N 4 Color Verde', '42500.00', 7, 'https://http2.mlstatic.com/D_NQ_NP_621700-MLU74832802358_032024-O.webp', NULL),
(30, 'Aletas Cortas Patas De Rana Natación Pileta Aquon® Smart', '44900.00', 9, 'https://http2.mlstatic.com/D_NQ_NP_985348-MLA54465285181_032023-O.webp', NULL),
(31, 'Patas De Rana Speedo Biofuse Aletas Cortas Natacion', '91111.00', 14, 'https://http2.mlstatic.com/D_NQ_NP_793535-MLA74611612551_022024-O.webp', NULL),
(32, 'Pelota De Voley Nassau Power Dinamic Nº 5 Color Rojo Para Indoor', '63000.00', 12, 'https://http2.mlstatic.com/D_NQ_NP_666750-MLU76817410423_062024-O.webp', NULL),
(33, 'Pelota Voley Cuero Sintético Bicolor Entrenamiento Volley Mg', '28800.00', 10, 'https://http2.mlstatic.com/D_NQ_NP_865201-MLA76112010865_042024-O.webp', NULL),
(34, 'Pelota Voley Munich Baxter Profesional Soft Touch Laminada', '35800.00', 21, 'https://http2.mlstatic.com/D_NQ_NP_936269-MLA74868630896_032024-O.webp', NULL),
(35, 'Par De Mancuernas 2kg C/u. Pesas Recubiertas Entrenamiento Color Negro', '6800.00', 2, 'https://http2.mlstatic.com/D_NQ_NP_861156-MLU75792379145_042024-O.webp', NULL),
(39, 'Shorts Deportivo Futbol Basquet Running Tenis Pádel Gym G6', '6789.00', 10, 'https://http2.mlstatic.com/D_NQ_NP_802703-MLA47920800029_102021-O.webp', NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `carritos`
--
ALTER TABLE `carritos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `compras`
--
ALTER TABLE `compras`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `producto_id` (`producto_id`);

--
-- Indices de la tabla `iniciosecionadmin`
--
ALTER TABLE `iniciosecionadmin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- Indices de la tabla `iniciosecionclientes`
--
ALTER TABLE `iniciosecionclientes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `correo` (`correo`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_admin` (`admin_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `carritos`
--
ALTER TABLE `carritos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT de la tabla `compras`
--
ALTER TABLE `compras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT de la tabla `iniciosecionadmin`
--
ALTER TABLE `iniciosecionadmin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `iniciosecionclientes`
--
ALTER TABLE `iniciosecionclientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `carritos`
--
ALTER TABLE `carritos`
  ADD CONSTRAINT `carritos_ibfk_1` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`);

--
-- Filtros para la tabla `compras`
--
ALTER TABLE `compras`
  ADD CONSTRAINT `compras_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `iniciosecionclientes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `compras_ibfk_2` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `productos`
--
ALTER TABLE `productos`
  ADD CONSTRAINT `fk_admin` FOREIGN KEY (`admin_id`) REFERENCES `iniciosecionadmin` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
